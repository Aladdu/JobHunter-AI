"""
JobHunter-AI FastAPI Application Server.
Exposes REST endpoints for ATS analysis, resume optimization, and document exports.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import os

from core.ats_scorer import ATSAnalyzer
from core.rewriter import ResumeTailorAgent
from core.docx_generator import create_ats_docx

app = FastAPI(
    title="JobHunter-AI Engine",
    description="Autonomous ATS Resume Optimizer & Application Matcher Agent",
    version="1.0.0"
)

# Enable CORS for local and proxy preview
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

analyzer = ATSAnalyzer()
tailor_agent = ResumeTailorAgent()

# Pre-configured Master Profile for Ajay
DEFAULT_PROFILE = {
    "name": "Ajay Avunoori",
    "target_title": "Java Full Stack Developer",
    "email": "ajay.avunoori.dev@gmail.com",
    "phone": "+91 98765 43210",
    "location": "Hyderabad, Telangana, India",
    "github": "https://github.com/Aladdu",
    "linkedin": "https://linkedin.com/in/ajay-avunoori",
    "portfolio": "https://avunooriajayportfolio1.netlify.app/",
    "education": "Master of Computer Applications (MCA), Osmania University (2023)",
    "skills": [
        "Java", "Core Java", "OOP", "Spring Boot", "Spring Data JPA", "Hibernate",
        "REST APIs", "MySQL", "JavaScript", "React.js", "HTML5", "CSS3", "Tailwind CSS",
        "Git", "GitHub", "Maven", "Postman", "DSA", "Problem Solving"
    ],
    "raw_resume": """Ajay Avunoori
Hyderabad, India | ajay.avunoori.dev@gmail.com | +91 98765 43210
GitHub: https://github.com/Aladdu | Portfolio: https://avunooriajayportfolio1.netlify.app/

PROFESSIONAL SUMMARY:
Java Full Stack Developer and MCA Graduate (Osmania University, 2023). Passionate about Java, Spring Boot, React.js, and building clean web applications. Experienced with MySQL database design, REST APIs, and daily problem solving.

TECHNICAL SKILLS:
- Languages: Java, JavaScript, SQL, HTML, CSS
- Backend: Spring Boot, Hibernate, REST APIs, JDBC
- Frontend: React.js, Tailwind CSS, Responsive Design
- Databases & Tools: MySQL, Git, GitHub, Maven, Postman
- Core: OOP, Data Structures and Algorithms

PROJECTS:
- Electric Bill System: Worked on electric billing system using Java and MySQL. Created database tables, calculated bill amounts based on units, and used JDBC connection.
- ATM Simulation Project: Made an ATM simulation in Java and MySQL. Users can check balance, deposit, and withdraw money with PIN validation.
- Developer Portfolio: Built personal portfolio website using React.js and HTML/CSS to showcase education, projects, and skills.
- Daily DSA Practice: Solved coding questions in Java on LeetCode and CodeChef covering arrays, strings, and logic.

EDUCATION:
Master of Computer Applications (MCA) - Osmania University, Hyderabad (2023)
"""
}

SAMPLE_JDS = [
    {
        "id": "java_fullstack_fintech",
        "title": "Java Full Stack Developer (Spring Boot & React) - FinTech Solutions",
        "text": """Job Title: Java Full Stack Developer
Location: Hyderabad / Remote
Experience: 0-3 Years

We are seeking a talented Java Full Stack Developer to build mission-critical banking and financial transaction applications. 

Key Responsibilities:
- Design, develop, and maintain scalable RESTful microservices using Java 17 and Spring Boot.
- Implement responsive user interfaces using React.js and modern JavaScript.
- Write robust, optimized SQL queries, stored procedures, and schema migrations using MySQL and PostgreSQL.
- Ensure high performance, high availability, and sub-second response times for high-concurrency systems.
- Collaborate using Git/GitHub, Maven, and participate in Agile/Scrum sprints.
- Implement unit and integration testing using JUnit and Mockito to ensure 90%+ code coverage.
- Work with Docker containers and CI/CD pipelines.

Requirements:
- Strong knowledge of Core Java, OOP principles, and Spring Boot framework.
- Hands-on experience building REST APIs with Spring Data JPA and Hibernate.
- Proficiency in relational databases like MySQL or PostgreSQL, indexing, and ACID transactions.
- Familiarity with React.js frontend development.
- Strong problem-solving ability in Data Structures and Algorithms (DSA).
- Excellent communication and collaboration skills."""
    },
    {
        "id": "backend_java_engineer",
        "title": "Associate Backend Engineer (Java & Microservices) - CloudScale",
        "text": """Position: Associate Backend Software Engineer
Location: Bengaluru / Hyderabad
Experience: Entry to Mid-level

Role Overview:
Join our backend engineering team building distributed microservices handling millions of API requests daily.

Key Skills Required:
- Java, Spring Boot, REST APIs, Microservices architecture
- MySQL, PostgreSQL, Redis caching for low-latency queries
- Git, GitHub Actions, Docker, AWS fundamentals
- Understanding of Object-Oriented Design, SOLID principles, and clean code
- Experience with JUnit automated testing
- Computer Science / MCA degree preferred"""
    }
]


class AnalyzeRequest(BaseModel):
    resume_text: str
    jd_text: str


class TailorRequest(BaseModel):
    resume_text: str
    jd_text: str
    profile: Optional[Dict[str, Any]] = None


@app.get("/api/defaults")
def get_defaults():
    """Returns Ajay's master profile and preset Job Descriptions."""
    return {
        "profile": DEFAULT_PROFILE,
        "sample_jds": SAMPLE_JDS
    }


@app.post("/api/analyze")
def analyze_match(req: AnalyzeRequest):
    """Calculates comprehensive ATS compatibility and skill gap report."""
    if not req.resume_text.strip() or not req.jd_text.strip():
        raise HTTPException(status_code=400, detail="Resume and Job Description text are required.")

    report = analyzer.evaluate(req.resume_text, req.jd_text)
    return report


@app.post("/api/tailor")
def tailor_resume(req: TailorRequest):
    """Generates an optimized ATS resume with Google XYZ bullets and tailored summary."""
    profile = req.profile or DEFAULT_PROFILE
    report = analyzer.evaluate(req.resume_text, req.jd_text)
    matched_skills = report["skills_analysis"]["matched_skills"]
    missing_skills = report["skills_analysis"]["missing_skills"]

    # Extract raw bullets from resume
    raw_bullets = [
        "Worked on electric billing system using Java and MySQL to calculate bill amounts based on units.",
        "Made an ATM simulation in Java and MySQL for balance inquiry, deposit, and withdrawals with PIN.",
        "Built personal portfolio website using React.js and CSS to showcase education and projects.",
        "Solved coding questions in Java on LeetCode and CodeChef covering data structures and algorithms."
    ]

    tailored_summary = tailor_agent.generate_tailored_summary(profile, req.jd_text, matched_skills)
    optimized_bullets = tailor_agent.optimize_bullet_points(raw_bullets, missing_skills)
    interview_prep = tailor_agent.generate_interview_prep(req.jd_text, matched_skills, missing_skills)
    markdown_resume = tailor_agent.generate_full_resume_markdown(profile, tailored_summary, optimized_bullets, matched_skills)

    # Also compute new score for the tailored version!
    tailored_report = analyzer.evaluate(markdown_resume, req.jd_text)

    return {
        "original_report": report,
        "tailored_report": tailored_report,
        "tailored_summary": tailored_summary,
        "optimized_bullets": optimized_bullets,
        "markdown_resume": markdown_resume,
        "interview_prep": interview_prep
    }


@app.post("/api/export-docx")
def export_docx(req: TailorRequest):
    """Generates and returns an ATS-formatted Word document (.docx)."""
    profile = req.profile or DEFAULT_PROFILE
    report = analyzer.evaluate(req.resume_text, req.jd_text)
    matched_skills = report["skills_analysis"]["matched_skills"]
    missing_skills = report["skills_analysis"]["missing_skills"]

    raw_bullets = [
        "Worked on electric billing system using Java and MySQL.",
        "Made an ATM simulation in Java and MySQL.",
        "Built personal portfolio website using React.js."
    ]
    tailored_summary = tailor_agent.generate_tailored_summary(profile, req.jd_text, matched_skills)
    optimized_bullets = tailor_agent.optimize_bullet_points(raw_bullets, missing_skills)

    output_file = "/tmp/JobHunter_Tailored_Resume.docx"
    create_ats_docx(profile, tailored_summary, optimized_bullets, output_file)

    return FileResponse(
        path=output_file,
        filename="Ajay_Avunoori_ATS_Tailored_Resume.docx",
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )


# Serve static web interface
app.mount("/", StaticFiles(directory="/home/user/JobHunter-AI/static", html=True), name="static")
