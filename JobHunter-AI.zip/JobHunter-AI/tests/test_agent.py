"""
Unit & Integration Tests for JobHunter-AI.
Verifies skill extraction, ATS scoring logic, bullet rewriting, and API responses.
"""

import pytest
from core.ats_scorer import ATSAnalyzer
from core.rewriter import ResumeTailorAgent


@pytest.fixture
def analyzer():
    return ATSAnalyzer()


@pytest.fixture
def tailor():
    return ResumeTailorAgent()


def test_skill_extraction(analyzer):
    sample_text = "Proficient in Java, Spring Boot, MySQL, and React.js with RESTful APIs."
    skills = analyzer.extract_all_skill_names(sample_text)
    
    assert "Java" in skills
    assert "Spring Boot" in skills
    assert "MySQL / PostgreSQL" in skills
    assert "React.js" in skills
    assert "RESTful APIs" in skills


def test_action_verbs_analysis(analyzer):
    text_with_verbs = "Architected a system, optimized database queries, and was responsible for testing."
    result = analyzer.analyze_action_verbs(text_with_verbs)
    
    assert result["strong_verbs_count"] >= 2
    assert "Architected" in result["strong_verbs"]
    assert "Optimized" in result["strong_verbs"]
    assert "responsible for" in result["weak_phrases"]


def test_ats_evaluation_scoring(analyzer):
    resume = """
    Ajay Avunoori | ajay@example.com | +91 9876543210
    Technical Skills: Java, Spring Boot, MySQL, React.js, Git
    Experience:
    Architected an automated Electric Billing System in Java and MySQL reducing processing time by 40%.
    Engineered an ATM simulation achieving sub-100ms response times.
    Education: Master of Computer Applications
    """
    jd = "Seeking Java developer with Spring Boot, MySQL, and React experience."
    
    report = analyzer.evaluate(resume, jd)
    assert report["overall_score"] >= 70
    assert len(report["skills_analysis"]["matched_skills"]) >= 3


def test_bullet_optimization_xyz(tailor):
    raw_bullets = [
        "Worked on electric billing system using Java and MySQL.",
        "Made an ATM simulation in Java."
    ]
    optimized = tailor.optimize_bullet_points(raw_bullets, missing_skills=["Docker"])
    assert len(optimized) == 2
    # Verify strong verbs and metrics exist in rewritten bullets
    assert any("Architected" in b["optimized"] or "Engineered" in b["optimized"] for b in optimized)
    assert any("%" in b["optimized"] or "ms" in b["optimized"] for b in optimized)


def test_interview_prep_generation(tailor):
    jd = "Looking for Senior Java Developer with Spring Boot and MySQL."
    matched_skills = ["Java", "Spring Boot", "MySQL / PostgreSQL"]
    missing_skills = ["Docker", "Kubernetes"]
    
    questions = tailor.generate_interview_prep(jd, matched_skills, missing_skills)
    assert len(questions) >= 4
    # Ensure bridge question for missing skill is generated
    assert any("Docker" in q["question"] for q in questions)
